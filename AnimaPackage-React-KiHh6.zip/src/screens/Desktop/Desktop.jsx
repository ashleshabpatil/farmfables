import React from "react";
import "./style.css";

export const Desktop = () => {
  return (
    <div className="desktop">
      <div className="overlap-wrapper">
        <div className="overlap">
          <div className="overlap-group">
            <img className="ellipse" alt="Ellipse" src="/img/ellipse-1.png" />
            <div className="text-wrapper">FarmFables</div>
            <div className="div">Sowing Knowledge, Growing Succes</div>
            <img className="rectangle" alt="Rectangle" src="/img/rectangle-1.png" />
            <img className="img" alt="Rectangle" src="/img/rectangle-2.png" />
            <img className="rectangle-2" alt="Rectangle" src="/img/rectangle-3.png" />
          </div>
          <div className="div-wrapper">
            <div className="text-wrapper-2">LOGIN</div>
          </div>
        </div>
      </div>
    </div>
  );
};
